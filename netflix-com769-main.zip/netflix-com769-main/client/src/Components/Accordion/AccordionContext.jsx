import React, { createContext } from "react";

const AccordionContext = React.createContext();

export default AccordionContext;
